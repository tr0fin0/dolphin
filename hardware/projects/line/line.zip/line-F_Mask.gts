%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-08-26T14:24:44+00:00*%
%TF.ProjectId,line,6c696e65-2e6b-4696-9361-645f70636258,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-26 14:24:44*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X0.350000X0.450000X-0.350000X0.450000X-0.350000X-0.450000X0.350000X-0.450000X0*%
%ADD11R,1.700000X1.700000*%
%ADD12C,1.700000*%
%ADD13RoundRect,0.197500X0.632500X-0.197500X0.632500X0.197500X-0.632500X0.197500X-0.632500X-0.197500X0*%
%ADD14RoundRect,0.250000X-0.350000X-0.450000X0.350000X-0.450000X0.350000X0.450000X-0.350000X0.450000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,R2*%
X145250000Y-113500000D03*
X143250000Y-113500000D03*
%TD*%
D11*
%TO.C,J1*%
X143710000Y-115750000D03*
D12*
X146250000Y-115750000D03*
X148790000Y-115750000D03*
%TD*%
D13*
%TO.C,U1*%
X144250000Y-111550000D03*
X148250000Y-111550000D03*
X148250000Y-109750000D03*
X144250000Y-109750000D03*
%TD*%
D14*
%TO.C,R1*%
X147250000Y-113500000D03*
X149250000Y-113500000D03*
%TD*%
M02*
